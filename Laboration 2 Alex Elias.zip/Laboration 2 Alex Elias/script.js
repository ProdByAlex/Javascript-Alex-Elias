const badge = document.querySelector('.fa.badge'); 
const addToCartBtn = document.querySelector('.cta-add'); 
const removeFromCartBtn = document.querySelector('.cta-select');

let cartCount = 0;

function updateBadge() {
  badge.setAttribute('value', cartCount);
}

function toggleRemoveButton() {
  if (cartCount > 0) {
    removeFromCartBtn.style.display = 'inline-block';
    removeFromCartBtn.textContent = 'Remove from cart';
  } else {
    removeFromCartBtn.style.display = 'none';
  }
}

addToCartBtn.addEventListener('click', () => {
  cartCount++;
  updateBadge();
  toggleRemoveButton();
});

removeFromCartBtn.addEventListener('click', () => {
  if (cartCount > 0) {
    cartCount--;
    updateBadge();
    toggleRemoveButton();
  }
});

updateBadge();
toggleRemoveButton();