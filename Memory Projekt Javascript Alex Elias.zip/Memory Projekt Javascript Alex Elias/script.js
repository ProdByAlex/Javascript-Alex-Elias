
document.addEventListener("DOMContentLoaded", function() {

    const cards = document.querySelectorAll('.card');


    cards.forEach(function(card) {
        card.addEventListener('click', function() {

            if (!card.classList.contains('flip')) {
                card.classList.add('flip'); 
            } else {
                card.classList.remove('flip'); 
            }
        });
    });
});


const timeDropdown = document.getElementById('timeDropdown');
let timeLimit = parseInt(timeDropdown.value); 


timeDropdown.addEventListener('change', function() {
    timeLimit = parseInt(timeDropdown.value);
    console.log("Tiden är nu satt till: " + timeLimit + " sekunder.");
});